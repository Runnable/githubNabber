![Alt text](https://circleci.com/gh/Runnable/dockworker.png?circle-token=bef3ad7daf52ec9c1a9e9b6294fc471713700ed2)


dockworker
==========

Run services in a docker container 
expose a terminal to the web
expose the file system to the web
and expose a build/run process to the web

in short expose as much of the system to the web as possible

